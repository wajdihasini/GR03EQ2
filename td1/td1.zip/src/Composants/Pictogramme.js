import React, { Component } from 'react';
import Icone from './Icone';

class Pictogramme extends Component {
  render() {
    return (
      <div>
        <Icone />
        <hr />
        <div>
          <button 
            type="button" 
            className="btn no-outline btn-secondary"
            onClick={this.props.actionAimer} // Déclenche la fonction du parent au clic
          >
            <i className="fa fa-thumbs-o-up fa-4 align-middle" aria-hidden="true"></i>
            &nbsp;
            <span className="align-middle">J'aime</span>
          </button>
        </div>
      </div>
    );
  }
}

export default Pictogramme;