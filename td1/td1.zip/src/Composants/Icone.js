import React from "react";

function Icone() {
  return <span>Icône</span>;
}

export default Icone;