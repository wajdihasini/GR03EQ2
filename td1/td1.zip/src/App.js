import React, { Component } from 'react';
import './App.css';

import Icone from './Composants/Icone';
import Pictogramme from './Composants/Pictogramme';
import Commentaire from './Composants/Commentaire';

class App extends Component {
  // Définition de l'état initial
  state = {
    message: 'Bonne découverte des composants React'
  };

  // Fonction pour modifier le message
  changerMessage = () => {
    this.setState({
      message: 'Premier défi réussi'
    });
  };

  render() {
    return (
      <div className="container mt-5">
        <div className="row">
          <div className="col-6 offset-3">
            <div className="card">
              <div className="card-block p-4">
                <div className="row">
                  <div className="col-2">
                    <img 
                      src="https://thomas-bart.com/wp-content/uploads/2017/03/developper-1680x1201.jpg" 
                      className="rounded float-left img-thumbnail" 
                      width="80" 
                      height="70" 
                      alt="avatar"
                    />
                  </div>
                  <div className="col-10 profile-row">
                    <div className="row">
                      <a href="#!"><h1> Débuter avec React </h1></a>
                    </div>
                  </div>
                </div>
                
                {/* Utilisation de la variable state.message */}
                <p className="mt-3">{this.state.message}</p>
                
                <div className="my-3">
                  <Icone />
                  <hr />
                  {/* On passe la fonction au composant Pictogramme via une prop */}
                  <Pictogramme actionAimer={this.changerMessage} />
                </div>
              </div>

              <div className="card-footer text-muted">
                <Commentaire />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;